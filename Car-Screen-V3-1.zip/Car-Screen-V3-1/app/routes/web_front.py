from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import desc
from app.db import SessionLocal
from app.models import MatchResult, Listing

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")

@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@router.get("/listings", response_class=HTMLResponse)
def listings_partial(request: Request, category: str = "PROFITABLE", min_conf: int = 0):
    db: Session = SessionLocal()
    try:
        q = db.query(MatchResult).join(Listing, MatchResult.listing_id==Listing.id).filter(MatchResult.category==category)
        if min_conf:
            q = q.filter(MatchResult.match_confidence>=min_conf)
        q = q.order_by(desc(MatchResult.margin_percent))
        rows = q.limit(200).all()
        return templates.TemplateResponse("partials/listing_table.html", {"request": request, "rows": rows})
    finally:
        db.close()
