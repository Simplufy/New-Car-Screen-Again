from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.routes.web_admin import authed
from app.services.apify_client import fetch_and_store_latest

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/admin/fetch")
async def manual_fetch(request: Request, db: Session = Depends(get_db)):
    if not authed(request):
        return RedirectResponse(url="/admin", status_code=303)

    inserted, skipped = await fetch_and_store_latest(db)

    return RedirectResponse(
        url=f"/admin?fetched={inserted}&skipped={skipped}",
        status_code=303,
    )
