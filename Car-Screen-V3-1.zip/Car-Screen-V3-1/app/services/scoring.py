from typing import Optional, Dict, Any
from app.config import settings
from app.models import Listing, Appraisal
from app.services.geo import haversine_miles

def pack_cost(price: int) -> int:
    for tier in settings.PACK_TIERS:
        if tier["min"] <= price <= tier["max"]:
            return int(tier["cost"])
    return 0

def recon_cost(year: int, mileage: Optional[int]) -> int:
    if mileage is not None and mileage <= settings.RECON_NEW_MILES_MAX:
        return settings.RECON_NEW_COST
    if year >= settings.RECON_OLD_YEAR_THRESHOLD:
        return settings.RECON_OLD_COST
    return settings.RECON_STANDARD_COST

def shipping_cost(listing: Listing) -> tuple[float, float, bool]:
    if listing.lat is not None and listing.lon is not None:
        miles = haversine_miles(listing.lat, listing.lon, settings.DEST_LAT, settings.DEST_LON)
        return miles, miles * settings.SHIPPING_RATE_PER_MILE, False
    return 0.0, 0.0, True

def score_listing(listing: Listing, appraisal: Optional[Appraisal]) -> Dict[str, Any]:
    if appraisal is None:
        return {"category":"SKIP","match_confidence":0,"explanations":{"reason":"no appraisal match"}}

    ship_miles, ship_cost_val, ship_unknown = shipping_cost(listing)
    recon = recon_cost(listing.year, listing.mileage)
    pack = pack_cost(listing.price)

    total_cost = listing.price + int(ship_cost_val) + recon + pack
    margin_dollars = appraisal.benchmark_price - total_cost
    margin_percent = (margin_dollars / total_cost) if total_cost > 0 else 0.0

    if margin_percent >= settings.PROFIT_MIN_PCT:
        category = "PROFITABLE"
    elif margin_percent >= settings.MAYBE_MIN_PCT:
        category = "MAYBE"
    else:
        category = "SKIP"

    explanations = {
        "shipping": {"miles": round(ship_miles,2), "rate": settings.SHIPPING_RATE_PER_MILE, "cost": round(ship_cost_val,2), "unknown": ship_unknown},
        "recon": recon,
        "pack": pack,
        "totals": {"total_cost": total_cost, "benchmark": appraisal.benchmark_price, "margin_dollars": margin_dollars, "margin_percent": round(margin_percent,4)},
        "thresholds": {"maybe_min_pct": settings.MAYBE_MIN_PCT, "profit_min_pct": settings.PROFIT_MIN_PCT}
    }

    return {
        "shipping_miles": ship_miles,
        "shipping_cost": int(ship_cost_val),
        "recon_cost": recon,
        "pack_cost": pack,
        "total_cost": total_cost,
        "gross_margin_dollars": margin_dollars,
        "margin_percent": margin_percent,
        "category": category,
        "explanations": explanations
    }
