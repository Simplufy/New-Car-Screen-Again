from typing import List, Dict, Any, Optional
from datetime import datetime

import httpx
from sqlalchemy.orm import Session

from app.config import settings
from app.models import Listing, MatchResult
from app.services.matching import find_best_appraisal_for_listing
from app.services.scoring import score_listing

APIFY_BASE = "https://api.apify.com/v2"


# ---------------------------
# 1) Fetch dataset items
# ---------------------------
async def fetch_latest_dataset_items(
    actor_id: str,
    runs_to_scan: int = 2,
    items_per_run_limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Pull items from the default datasets of the last N runs of an Apify Actor.
    actor_id must be the slug form, e.g. 'epctex~autotrader-scraper'.
    """
    if not settings.APIFY_TOKEN or not actor_id:
        return []

    params = {"token": settings.APIFY_TOKEN}
    items: List[Dict[str, Any]] = []

    async with httpx.AsyncClient(timeout=30) as client:
        # Get recent runs for this actor
        runs_resp = await client.get(f"{APIFY_BASE}/actors/{actor_id}/runs", params=params)
        runs_resp.raise_for_status()
        runs = runs_resp.json().get("data", {}).get("items", [])[:runs_to_scan]

        # For each run, fetch its default dataset
        for run in runs:
            dataset_id = run.get("defaultDatasetId")
            if not dataset_id:
                continue
            ds_params = {"token": settings.APIFY_TOKEN}
            if items_per_run_limit:
                ds_params["limit"] = items_per_run_limit

            ds_resp = await client.get(f"{APIFY_BASE}/datasets/{dataset_id}/items", params=ds_params)
            ds_resp.raise_for_status()
            items.extend(ds_resp.json())

    return items


# ---------------------------
# 2) Normalize one listing row
# ---------------------------
def normalize_autotrader_item(item: Dict[str, Any]) -> Dict[str, Any]:
    def g(*keys, default=None):
        for k in keys:
            if k in item and item[k] is not None:
                return item[k]
        return default

    # price cleanup (string to int)
    price = g("price", "listingPrice", "currentPrice")
    if isinstance(price, str):
        try:
            price = int("".join(ch for ch in price if ch.isdigit()))
        except Exception:
            price = None

    # mileage cleanup (e.g., "20,345" -> 20345; "20k" -> 20000)
    mileage = g("mileage", "odometer")
    if isinstance(mileage, str):
        s = mileage.strip().lower()
        if s.endswith("k") and s[:-1].isdigit():
            mileage = int(s[:-1]) * 1000
        else:
            digits = "".join(ch for ch in s if ch.isdigit())
            mileage = int(digits) if digits else None

    return {
        "vin": g("vin", "VIN"),
        "year": g("year"),
        "make": g("make"),
        "model": g("model"),
        "trim": g("trim"),
        "price": price,
        "mileage": mileage,
        "url": g("url", "detailUrl", "listingUrl"),
        "seller": g("seller", "sellerName"),
        "seller_type": g("sellerType"),
        "location": g("location", "cityState", "city_state"),
        "lat": g("lat", "latitude"),
        "lon": g("lon", "longitude", "lng"),
        "zip": g("zip", "postalCode", "postal_code"),
        "raw": item,
    }


# ---------------------------
# 3) Fetch + upsert + score
# ---------------------------
async def fetch_and_store_latest(
    db: Session,
    runs_to_scan: int = 2,
    items_per_run_limit: Optional[int] = None,
) -> tuple[int, int]:
    """
    Pull latest dataset items from Apify, upsert Listings by VIN,
    score them against the appraisal DB, and return (inserted_count, skipped_count).
    """
    inserted = 0
    skipped = 0

    # Guard: missing config
    if not settings.APIFY_ACTOR_ID or not settings.APIFY_TOKEN:
        return (inserted, skipped)

    items = await fetch_latest_dataset_items(
        settings.APIFY_ACTOR_ID,
        runs_to_scan=runs_to_scan,
        items_per_run_limit=items_per_run_limit,
    )

    for raw in items:
        norm = normalize_autotrader_item(raw)
        vin = norm.get("vin")
        price = norm.get("price")

        # Skip rows without VIN or price
        if not vin or not price:
            skipped += 1
            continue

        # Upsert by VIN
        listing = db.query(Listing).filter(Listing.vin == vin).first()
        is_new = listing is None
        if is_new:
            listing = Listing(**norm)
            db.add(listing)
        else:
            for k, v in norm.items():
                setattr(listing, k, v)
            listing.ingested_at = datetime.utcnow()

        db.commit()
        db.refresh(listing)

        # Match & score
        appraisal, level, conf = find_best_appraisal_for_listing(db, listing)
        res = score_listing(listing, appraisal)

        match = db.query(MatchResult).filter(MatchResult.listing_id == listing.id).first()
        if match is None:
            match = MatchResult(
                listing_id=listing.id,
                appraisal_id=appraisal.id if appraisal else None,
                match_level=level,
                match_confidence=conf,
                shipping_miles=res.get("shipping_miles"),
                shipping_cost=res.get("shipping_cost"),
                recon_cost=res.get("recon_cost"),
                pack_cost=res.get("pack_cost"),
                total_cost=res.get("total_cost"),
                gross_margin_dollars=res.get("gross_margin_dollars"),
                margin_percent=res.get("margin_percent"),
                category=res.get("category"),
                explanations=res.get("explanations"),
                scored_at=datetime.utcnow(),
            )
            db.add(match)
        else:
            match.appraisal_id = appraisal.id if appraisal else None
            match.match_level = level
            match.match_confidence = conf
            for k, v in res.items():
                if k == "explanations":
                    match.explanations = v
                elif hasattr(match, k):
                    setattr(match, k, v)
            match.scored_at = datetime.utcnow()

        db.commit()

        if is_new:
            inserted += 1

    return (inserted, skipped)
